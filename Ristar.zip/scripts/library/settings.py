import pygame

class Settings:
    def __init__(self):
        self.TILE_SIZE = 32
        self.FPS = 80

settings = Settings()





